const progressBar = document.querySelector(".scroll-progress__bar");
const backToTop = document.querySelector(".back-to-top");
const revealElements = document.querySelectorAll("[data-reveal]");
const navigationLinks = document.querySelectorAll('.site-nav a[href^="#"]');
const sections = document.querySelectorAll("main section[id]");

document.documentElement.classList.add("js-ready");

let scrollUpdatePending = false;

function updateScrollUI() {
    const scrollableHeight = document.documentElement.scrollHeight - window.innerHeight;
    const progress = scrollableHeight > 0 ? (window.scrollY / scrollableHeight) * 100 : 0;

    progressBar.style.width = `${Math.min(progress, 100)}%`;
    backToTop.classList.toggle("is-visible", window.scrollY > 560);
    scrollUpdatePending = false;
}

function requestScrollUpdate() {
    if (scrollUpdatePending) {
        return;
    }

    scrollUpdatePending = true;
    window.requestAnimationFrame(updateScrollUI);
}

window.addEventListener("scroll", requestScrollUpdate, { passive: true });
window.addEventListener("resize", requestScrollUpdate);
updateScrollUI();

if ("IntersectionObserver" in window) {
    const revealObserver = new IntersectionObserver((entries, observer) => {
        entries.forEach((entry) => {
            if (entry.isIntersecting) {
                entry.target.classList.add("is-visible");
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.14 });

    revealElements.forEach((element) => revealObserver.observe(element));

    const navigationObserver = new IntersectionObserver((entries) => {
        entries.forEach((entry) => {
            if (!entry.isIntersecting) {
                return;
            }

            navigationLinks.forEach((link) => {
                const isCurrentSection = link.hash === `#${entry.target.id}`;

                if (isCurrentSection) {
                    link.setAttribute("aria-current", "location");
                } else {
                    link.removeAttribute("aria-current");
                }
            });
        });
    }, { rootMargin: "-30% 0px -60% 0px" });

    sections.forEach((section) => navigationObserver.observe(section));
} else {
    revealElements.forEach((element) => element.classList.add("is-visible"));
}
